package exception;

public class TestArrayMetException {
    public static void main(String[] args) {
//        Voorbeeld1 vb1 = new Voorbeeld1();
//        vb1.drukAf();
//     Voorbeeld2 vb2 = new Voorbeeld2();
//        vb2.drukAf();

    }

}
